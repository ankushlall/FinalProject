from django.db import models
from django.contrib.auth.models import User

# Create your models here.
BREED_CHOICE = (
    ('Gyr Cattle','Gyr Cattle'),
    ('Sahiwal Cattle','Sahiwal Cattle'),
    ('Tharparkar Cattle','Tharparkar Cattle'),
    ('Red Sindhi','Red Sindhi'),
    ('Ongole Cattle','Ongole Cattle'),
    ('Rathi Cattle','Rathi Cattle'),
    ('Hallikar','Hallikar'),
    ('Hariana Cattle','Hariana Cattle'),
    ('Kangayam Cattle','Kangayam Cattle'),
    ('Amrit Mahal', 'Amrit Mahal'),
    ('Khillari Cattle','Khillari Cattle'),
    ('Krishna Valley','Krishna Valley'),
    ('Malvi','Malvi'),
    ('Bargur Cattle','Bargur Cattle'),
    ('Vechur Cattle','Vechur Cattle'),
    ('Umblachery','Umblachery'),
    ('Dangi Cattle','Dangi Cattle'),
    ('Kherigarh','Kherigarh'),
    ('Murrah buffalo','Murrah buffalo'),
    ('Bachaur Cattle','Bachaur Cattle'),
    ('Ponwar Cattle','Ponwar Cattle'),
    ('Pulikulam','Pulikulam'),
    ('Siri Cattle','Siri Cattle'),
    ('Nimari Cattle','Nimari Cattle'),
    ('Kenkatha','Kenkatha'),
    ('Red Kandhari','Red Kandhari'),
    ('Punganur Cattle','Punganur Cattle'),
    ('Gaolao', 'Gaolao'),
    ('Malnad Gidda','Malnad Gidda'),
    ('Alambadi','Alambadi'),
    ('Gangatiri','Gangatiri'),
    ('Jafarabadi Buffalo','Jafarabadi Buffalo'),
    ('American Brahman', 'American Brahman'),
    ('Nili-Ravi','Nili-Ravi'),
    ('Nagpuri','Nagpuri '),
    ('Guzerat','Guzerat'),
    ('Mewati Cattle','Mewati Cattle'),
    ('Kasaragod Dwarf','Kasaragod Dwarf'),
    ('Sunandini','Sunandini'),
    ('Nelore','Nelore'),
    ('Javari Cattle','Javari Cattle'),
)
class Cattle(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    age = models.PositiveIntegerField(default=0)
    breed = models.CharField(choices=BREED_CHOICE, max_length=100)
    milk = models.PositiveIntegerField(default=0)
    offspring = models.PositiveIntegerField(default=0)

    def __str__(self):
        return str(self.id)




