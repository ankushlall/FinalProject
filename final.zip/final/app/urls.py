from django.urls import path
from app import views
from django.contrib.auth import views as auth_views
from.forms import UserLoginForm
urlpatterns = [
    path('', views.home, name='home'),
    path('registration/', views.UserRegistrationView.as_view(),name='registration'),
    path('accounts/login/', auth_views.LoginView.as_view(template_name='app/login.html', authentication_form=UserLoginForm), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
    path('profile/', views.ProfileView.as_view(), name='profile'),
    path('showcattle/', views.ShowCattleView, name='showcattle'),
    path('cattle-details/<int:pk>',views.CattleDetailView.as_view(), name='cattle-details'),
    
    ] 