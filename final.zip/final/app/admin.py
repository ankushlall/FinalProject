from django.contrib import admin
from .models import User, Cattle

# Register your models here.

@admin.register(Cattle)
class CattleModelAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'age', 'breed', 'milk', 'offspring']
