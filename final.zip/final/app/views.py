from django.shortcuts import render
from django.views import View
from .forms import UserRegistrationForm, CattleForm
from django.contrib import messages
from .models import Cattle

# Create your views here.
def home(request):
    return render(request, 'app/home.html')

def ShowCattleView(request):
    cattle = Cattle.objects.filter(user=request.user)
    return render(request, 'app/cattle.html', {'cattle':cattle, 'active':'btn-primary'})

class CattleDetailView(View):
    def get(self, request, pk):
        cow = Cattle.objects.get(pk=pk)
        return render(request, 'app/cattle_detail.html', {'cow':cow})

    

class UserRegistrationView(View):
    def get(self, request):
        form = UserRegistrationForm()
        return render(request, 'app/registration.html', {'form':form})
    def post(self, request):
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            messages.success(request, 'Congratulations Registered Successfully!!!')
            form.save()
        return render(request, 'app/registration.html', {'form':form})

class ProfileView(View):
    def get(self, request):
        form = CattleForm()
        return render(request, 'app/profile.html',{'form':form, 'active':'btn-primary'})
    def post(self, request):
        form = CattleForm(request.POST)
        if form.is_valid():
            usr = request.user
            age = form.cleaned_data['age']
            breed = form.cleaned_data['breed']
            milk = form.cleaned_data['milk']
            offspring = form.cleaned_data['offspring']
            reg = Cattle(user=usr, age=age, breed=breed, milk=milk, offspring=offspring)
            reg.save()
            messages.success(request, 'Cattle Successfully Registered...')
        return render(request, 'app/profile.html', {'form':form, 'active':'btn-primary'})

        
